# ChurnWise — Customer Churn Prediction System

A full-stack machine-learning web application that predicts customer churn probability and stores prediction history for analytics.

## Stack

- Frontend: React + Vite + Tailwind CSS + Recharts
- Backend: Flask + Flask-CORS
- ML: Pandas + NumPy + scikit-learn + Joblib
- Database: SQLite
- Deployment: Gunicorn-ready Flask backend

## Important dataset note

The included `dataset/customer_churn.csv` is a deterministic synthetic Telco-style dataset generated for this runnable demo. It is not presented as real customer data. For a production/business deployment, replace it with an appropriately licensed, de-identified dataset and retrain the model.

## Features

- Real ML inference through a Flask API
- Logistic Regression and Random Forest model comparison
- Model selection by held-out ROC-AUC, with F1 as a secondary criterion
- Probability-based Low / Medium / High risk levels
- SQLite prediction history
- Dashboard charts
- Search/filter/sort history
- Responsive SaaS UI
- API validation and error handling
- Automatic first-run model training
- Gunicorn deployment configuration

## Run locally

### 1. Backend

From the project root:

```bash
cd backend
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Train the model explicitly:

```bash
python model/train_model.py
```

Start the API:

```bash
python app.py
```

The API runs on `http://localhost:5000`.

The API also automatically trains the model on first startup if `backend/model/churn_model.pkl` does not exist.

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal, normally `http://localhost:5173`.

If your backend is hosted elsewhere, create `frontend/.env`:

```env
VITE_API_URL=https://your-backend.example.com/api
```

## API

### Health

`GET /api/health`

### Prediction

`POST /api/predict`

Example request:

```json
{
  "gender": "Male",
  "SeniorCitizen": 0,
  "Partner": "No",
  "Dependents": "No",
  "tenure": 12,
  "PhoneService": "Yes",
  "InternetService": "Fiber optic",
  "Contract": "Month-to-month",
  "PaymentMethod": "Electronic check",
  "MonthlyCharges": 75,
  "TotalCharges": 900,
  "TechSupport": "No",
  "OnlineSecurity": "No",
  "OnlineBackup": "No",
  "DeviceProtection": "No",
  "StreamingTV": "No",
  "StreamingMovies": "No"
}
```

### Dashboard

`GET /api/dashboard`

### History

`GET /api/history`

### Model metrics

`GET /api/model-metrics`

## Model evaluation

The training script evaluates:

- Accuracy
- Precision
- Recall
- F1
- ROC-AUC

Accuracy is not used as the only selection criterion.

## Architecture

```text
React + Tailwind + Recharts
          |
          | REST / JSON
          v
      Flask API
          |
          +---- scikit-learn Pipeline
          |         |
          |         +-- preprocessing
          |         +-- classifier
          |
          +---- SQLite prediction history
```

## Deployment

### Backend

Deploy the `backend` directory to a Python host that supports Gunicorn. The included `Procfile` uses:

```text
web: gunicorn app:app
```

Set:

```text
CORS_ORIGINS=https://your-frontend.example.com
```

### Frontend

Build:

```bash
npm run build
```

Deploy the generated `frontend/dist` directory to a static hosting provider. Set `VITE_API_URL` to the deployed API base URL before building.

## Resume-ready project statement

**ChurnWise — Customer Churn Prediction System:** Built a full-stack ML application using React, Flask, scikit-learn and SQLite to predict customer churn probability, compare classification models, persist prediction history, and visualize churn analytics through an interactive dashboard.
