import os
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, request
from flask_cors import CORS
import joblib
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model" / "churn_model.pkl"
DB_PATH = BASE_DIR / "database" / "churnwise.db"

FEATURES = [
    "gender", "SeniorCitizen", "Partner", "Dependents", "tenure",
    "PhoneService", "InternetService", "Contract", "PaymentMethod",
    "MonthlyCharges", "TotalCharges", "TechSupport", "OnlineSecurity",
    "OnlineBackup", "DeviceProtection", "StreamingTV", "StreamingMovies"
]

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": os.getenv("CORS_ORIGINS", "*").split(",")}})

def get_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id TEXT NOT NULL,
            customer_json TEXT NOT NULL,
            churn_probability REAL NOT NULL,
            prediction TEXT NOT NULL,
            risk_level TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

def ensure_model():
    if not MODEL_PATH.exists():
        from model.train_model import train_and_save
        train_and_save()

def load_model():
    ensure_model()
    return joblib.load(MODEL_PATH)

def normalize_payload(data):
    required = {
        "gender","SeniorCitizen","Partner","Dependents","tenure",
        "PhoneService","InternetService","Contract","PaymentMethod",
        "MonthlyCharges","TotalCharges","TechSupport","OnlineSecurity",
        "OnlineBackup","DeviceProtection","StreamingTV","StreamingMovies"
    }
    missing = sorted(required - set(data.keys()))
    if missing:
        raise ValueError(f"Missing fields: {', '.join(missing)}")

    result = dict(data)
    try:
        result["SeniorCitizen"] = int(result["SeniorCitizen"])
        result["tenure"] = int(result["tenure"])
        result["MonthlyCharges"] = float(result["MonthlyCharges"])
        result["TotalCharges"] = float(result["TotalCharges"])
    except (TypeError, ValueError):
        raise ValueError("Numeric customer fields contain invalid values")

    if result["SeniorCitizen"] not in (0, 1):
        raise ValueError("SeniorCitizen must be 0 or 1")
    if not 0 <= result["tenure"] <= 100:
        raise ValueError("Tenure must be between 0 and 100 months")
    if result["MonthlyCharges"] < 0 or result["TotalCharges"] < 0:
        raise ValueError("Charges cannot be negative")

    return result

def risk_level(probability):
    if probability >= 0.70:
        return "High"
    if probability >= 0.40:
        return "Medium"
    return "Low"

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "model_ready": MODEL_PATH.exists()})

@app.post("/api/predict")
def predict():
    try:
        payload = normalize_payload(request.get_json(silent=True) or {})
        model = load_model()
        frame = pd.DataFrame([payload], columns=FEATURES)
        probability = float(model.predict_proba(frame)[0][1])
        prediction = "Churn" if probability >= 0.50 else "No Churn"
        risk = risk_level(probability)
        customer_id = payload.get("customerID") or f"WEB-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')[:-3]}"

        conn = get_db()
        conn.execute(
            """INSERT INTO predictions
               (customer_id, customer_json, churn_probability, prediction, risk_level, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (customer_id, json.dumps(payload), probability, prediction, risk, datetime.now(timezone.utc).isoformat())
        )
        conn.commit()
        conn.close()

        recommendations = []
        if payload["Contract"] == "Month-to-month":
            recommendations.append("Offer a longer-term plan with a clear loyalty benefit.")
        if payload["TechSupport"] == "No" and payload["InternetService"] != "No":
            recommendations.append("Consider a proactive technical-support offer.")
        if payload["OnlineSecurity"] == "No" and payload["InternetService"] != "No":
            recommendations.append("Bundle online security with the current service.")
        if payload["tenure"] < 12:
            recommendations.append("Use an early-tenure retention journey and onboarding support.")
        if payload["MonthlyCharges"] > 85:
            recommendations.append("Review pricing or plan fit before renewal.")
        if not recommendations:
            recommendations.append("Continue personalized engagement and monitor future risk.")

        return jsonify({
            "customer_id": customer_id,
            "prediction": prediction,
            "probability": round(probability, 4),
            "probability_percent": round(probability * 100, 1),
            "risk_level": risk,
            "recommendations": recommendations
        })
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception:
        app.logger.exception("Prediction failed")
        return jsonify({"error": "Prediction service failed. Check the backend logs."}), 500

@app.get("/api/history")
def history():
    conn = get_db()
    rows = conn.execute(
        """SELECT id, customer_id, churn_probability, prediction, risk_level, created_at
           FROM predictions ORDER BY id DESC"""
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.get("/api/dashboard")
def dashboard():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) c FROM predictions").fetchone()["c"]
    churn = conn.execute("SELECT COUNT(*) c FROM predictions WHERE prediction='Churn'").fetchone()["c"]
    recent = conn.execute(
        """SELECT id, customer_id, churn_probability, prediction, risk_level, created_at
           FROM predictions ORDER BY id DESC LIMIT 6"""
    ).fetchall()
    by_contract = conn.execute("""
        SELECT json_extract(customer_json, '$.Contract') contract,
               COUNT(*) total,
               SUM(CASE WHEN prediction='Churn' THEN 1 ELSE 0 END) churn
        FROM predictions GROUP BY contract ORDER BY total DESC
    """).fetchall()
    by_internet = conn.execute("""
        SELECT json_extract(customer_json, '$.InternetService') service,
               COUNT(*) total,
               SUM(CASE WHEN prediction='Churn' THEN 1 ELSE 0 END) churn
        FROM predictions GROUP BY service ORDER BY total DESC
    """).fetchall()
    conn.close()

    churn_pct = round((churn / total) * 100, 1) if total else 0
    return jsonify({
        "total_predictions": total,
        "churn_predictions": churn,
        "non_churn_predictions": total - churn,
        "churn_percentage": churn_pct,
        "recent": [dict(r) for r in recent],
        "by_contract": [dict(r) for r in by_contract],
        "by_internet": [dict(r) for r in by_internet]
    })

@app.get("/api/model-metrics")
def model_metrics():
    metrics_path = BASE_DIR / "model" / "metrics.json"
    if not metrics_path.exists():
        ensure_model()
    return jsonify(json.loads(metrics_path.read_text(encoding="utf-8")))

if __name__ == "__main__":
    init_db()
    ensure_model()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
