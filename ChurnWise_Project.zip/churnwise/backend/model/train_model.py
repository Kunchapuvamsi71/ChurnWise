import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR.parent / "dataset" / "customer_churn.csv"
MODEL_PATH = BASE_DIR / "model" / "churn_model.pkl"
METRICS_PATH = BASE_DIR / "model" / "metrics.json"

FEATURES = [
    "gender", "SeniorCitizen", "Partner", "Dependents", "tenure",
    "PhoneService", "InternetService", "Contract", "PaymentMethod",
    "MonthlyCharges", "TotalCharges", "TechSupport", "OnlineSecurity",
    "OnlineBackup", "DeviceProtection", "StreamingTV", "StreamingMovies"
]
CATEGORICAL = [
    "gender", "Partner", "Dependents", "PhoneService", "InternetService",
    "Contract", "PaymentMethod", "TechSupport", "OnlineSecurity",
    "OnlineBackup", "DeviceProtection", "StreamingTV", "StreamingMovies"
]
NUMERIC = ["SeniorCitizen", "tenure", "MonthlyCharges", "TotalCharges"]

def build_preprocessor():
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    return ColumnTransformer([
        ("num", numeric_pipe, NUMERIC),
        ("cat", categorical_pipe, CATEGORICAL)
    ])

def evaluate(model, X_test, y_test):
    pred = model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1]
    return {
        "accuracy": round(accuracy_score(y_test, pred), 4),
        "precision": round(precision_score(y_test, pred, zero_division=0), 4),
        "recall": round(recall_score(y_test, pred, zero_division=0), 4),
        "f1": round(f1_score(y_test, pred, zero_division=0), 4),
        "roc_auc": round(roc_auc_score(y_test, proba), 4)
    }

def train_and_save():
    df = pd.read_csv(DATA_PATH)
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    X = df[FEATURES].copy()
    y = (df["Churn"] == "Yes").astype(int)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    candidates = {
        "Logistic Regression": LogisticRegression(max_iter=2000, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(
            n_estimators=350, max_depth=12, min_samples_leaf=2,
            random_state=42, class_weight="balanced"
        )
    }

    results, fitted = {}, {}
    for name, estimator in candidates.items():
        pipeline = Pipeline([
            ("preprocessor", build_preprocessor()),
            ("classifier", estimator)
        ])
        pipeline.fit(X_train, y_train)
        results[name] = evaluate(pipeline, X_test, y_test)
        fitted[name] = pipeline

    selected = max(results, key=lambda name: (results[name]["roc_auc"], results[name]["f1"]))
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(fitted[selected], MODEL_PATH)

    metrics = {
        "selected_model": selected,
        "test_size": len(X_test),
        "dataset_rows": len(df),
        "class_distribution": {"churn": int(y.sum()), "no_churn": int((1-y).sum())},
        "models": results
    }
    METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return metrics

if __name__ == "__main__":
    print(json.dumps(train_and_save(), indent=2))
