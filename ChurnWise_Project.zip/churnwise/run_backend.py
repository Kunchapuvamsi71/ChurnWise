from backend.app import app, init_db, ensure_model
if __name__ == "__main__":
    init_db()
    ensure_model()
    app.run(host="0.0.0.0", port=5000, debug=False)
