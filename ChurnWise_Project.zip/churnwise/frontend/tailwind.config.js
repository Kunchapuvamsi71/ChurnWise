/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: { navy: '#050B1D' },
      boxShadow: { glow: '0 0 40px rgba(59,130,246,.16)' }
    }
  },
  plugins: []
}
