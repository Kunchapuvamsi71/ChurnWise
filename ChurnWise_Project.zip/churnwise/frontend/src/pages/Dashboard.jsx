import { useEffect, useState } from 'react'
import { api } from '../services/api'
import Loading from '../components/Loading'
import StatCard from '../components/StatCard'
import { Users, UserX, UserCheck, Percent, Activity } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, CartesianGrid, LineChart, Line } from 'recharts'

export default function Dashboard(){
  const [data,setData]=useState(null),[metrics,setMetrics]=useState(null),[error,setError]=useState('')
  useEffect(()=>{Promise.all([api.dashboard(),api.metrics()]).then(([d,m])=>{setData(d);setMetrics(m)}).catch(e=>setError(e.message))},[])
  if(error)return <div className="mx-auto max-w-7xl px-5 py-20 text-center text-red-300">{error}</div>
  if(!data)return <Loading label="Loading dashboard..."/>
  const pie=[{name:'Churn',value:data.churn_predictions},{name:'No Churn',value:data.non_churn_predictions}]
  return <div className="mx-auto max-w-7xl px-5 py-12"><div className="mb-10"><div className="text-xs tracking-[.25em] text-blue-400">DASHBOARD</div><h1 className="mt-2 text-4xl font-bold">Churn Analytics</h1><p className="mt-3 text-slate-400">Live analytics based on predictions stored in SQLite.</p></div>
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4"><StatCard label="Total Predictions" value={data.total_predictions} icon={Users}/><StatCard label="Predicted Churn" value={data.churn_predictions} icon={UserX}/><StatCard label="No Churn" value={data.non_churn_predictions} icon={UserCheck}/><StatCard label="Churn Rate" value={`${data.churn_percentage}%`} icon={Percent}/></div>
    <div className="mt-6 grid gap-6 lg:grid-cols-2"><div className="glass rounded-2xl p-5"><h2 className="font-semibold">Churn vs No Churn</h2><div className="mt-6 h-72">{data.total_predictions?<ResponsiveContainer><PieChart><Pie data={pie} dataKey="value" nameKey="name" innerRadius={72} outerRadius={105} paddingAngle={4}>{pie.map((_,i)=><Cell key={i} fill={i===0?'#fb7185':'#60a5fa'}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer>:<Empty/>}</div></div>
    <div className="glass rounded-2xl p-5"><h2 className="font-semibold">Churn by Contract</h2><div className="mt-6 h-72">{data.by_contract.length?<ResponsiveContainer><BarChart data={data.by_contract}><CartesianGrid strokeDasharray="3 3" stroke="#1e293b"/><XAxis dataKey="contract" tick={{fill:'#94a3b8',fontSize:11}}/><YAxis tick={{fill:'#94a3b8',fontSize:11}}/><Tooltip/><Bar dataKey="churn" fill="#8b5cf6" radius={[6,6,0,0]}/></BarChart></ResponsiveContainer>:<Empty/>}</div></div></div>
    <div className="mt-6 glass rounded-2xl p-5"><h2 className="font-semibold">Model Evaluation</h2><p className="mt-1 text-xs text-slate-500">Selected by test ROC-AUC, with F1 as a secondary criterion.</p><div className="mt-5 grid gap-4 md:grid-cols-2">{Object.entries(metrics.models).map(([name,m])=><div key={name} className={`rounded-2xl border p-5 ${metrics.selected_model===name?'border-blue-400/40 bg-blue-400/5':'border-slate-800 bg-slate-900/40'}`}><div className="flex items-center justify-between"><b>{name}</b>{metrics.selected_model===name&&<span className="text-xs text-blue-300">Selected</span>}</div><div className="mt-4 grid grid-cols-5 gap-2 text-center">{[['Accuracy',m.accuracy],['Precision',m.precision],['Recall',m.recall],['F1',m.f1],['ROC-AUC',m.roc_auc]].map(([k,v])=><div key={k}><div className="text-lg font-bold">{v}</div><div className="text-[10px] text-slate-500">{k}</div></div>)}</div></div>)}</div></div>
  </div>
}
function Empty(){return <div className="grid h-full place-items-center text-sm text-slate-500">No prediction data yet. Run a prediction first.</div>}
