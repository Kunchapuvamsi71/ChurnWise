import { useState } from 'react'
import { api } from '../services/api'
import { AlertCircle, CheckCircle2, Loader2, Sparkles } from 'lucide-react'

const initial = {
  gender:'Male', SeniorCitizen:0, Partner:'No', Dependents:'No', tenure:12,
  PhoneService:'Yes', InternetService:'Fiber optic', Contract:'Month-to-month',
  PaymentMethod:'Electronic check', MonthlyCharges:75, TotalCharges:900,
  TechSupport:'No', OnlineSecurity:'No', OnlineBackup:'No', DeviceProtection:'No',
  StreamingTV:'No', StreamingMovies:'No'
}
const selects = {
  gender:['Male','Female'],
  SeniorCitizen:[0,1],
  Partner:['Yes','No'], Dependents:['Yes','No'], PhoneService:['Yes','No'],
  InternetService:['DSL','Fiber optic','No'],
  Contract:['Month-to-month','One year','Two year'],
  PaymentMethod:['Electronic check','Mailed check','Bank transfer (automatic)','Credit card (automatic)'],
  TechSupport:['Yes','No','No internet service'], OnlineSecurity:['Yes','No','No internet service'],
  OnlineBackup:['Yes','No','No internet service'], DeviceProtection:['Yes','No','No internet service'],
  StreamingTV:['Yes','No','No internet service'], StreamingMovies:['Yes','No','No internet service']
}
const labels = {SeniorCitizen:'Senior Citizen',MonthlyCharges:'Monthly Charges',TotalCharges:'Total Charges',PhoneService:'Phone Service',InternetService:'Internet Service',PaymentMethod:'Payment Method',TechSupport:'Tech Support',OnlineSecurity:'Online Security',OnlineBackup:'Online Backup',DeviceProtection:'Device Protection',StreamingTV:'Streaming TV',StreamingMovies:'Streaming Movies'}

export default function Predict(){
  const [form,setForm]=useState(initial), [result,setResult]=useState(null), [loading,setLoading]=useState(false), [error,setError]=useState('')
  const set=(k,v)=>setForm(f=>({...f,[k]:v}))
  const submit=async(e)=>{e.preventDefault();setError('');setResult(null);setLoading(true);try{setResult(await api.predict(form))}catch(err){setError(err.message)}finally{setLoading(false)}}
  const field=(key)=>{
    const label=labels[key]||key
    return <label key={key} className="block"><span className="mb-2 block text-sm text-slate-300">{label}</span>{selects[key]?<select value={form[key]} onChange={e=>set(key,key==='SeniorCitizen'?Number(e.target.value):e.target.value)} className="w-full rounded-xl border border-slate-700 bg-slate-900/70 px-3 py-3 outline-none focus:border-blue-400">{selects[key].map(x=><option key={x} value={x}>{String(x)}</option>)}</select>:<input type={['tenure','MonthlyCharges','TotalCharges'].includes(key)?'number':'text'} min={key==='tenure'?0:undefined} step={key==='tenure'?1:.01} value={form[key]} onChange={e=>set(key,['tenure','MonthlyCharges','TotalCharges'].includes(key)?Number(e.target.value):e.target.value)} className="w-full rounded-xl border border-slate-700 bg-slate-900/70 px-3 py-3 outline-none focus:border-blue-400"/>}</label>
  }
  return <div className="mx-auto max-w-7xl px-5 py-12"><div className="mb-10"><div className="text-xs tracking-[.25em] text-blue-400">PREDICT</div><h1 className="mt-2 text-4xl font-bold">Customer Churn Prediction</h1><p className="mt-3 text-slate-400">Enter customer details and get a model-generated churn probability.</p></div>
    <div className="grid gap-8 lg:grid-cols-[1.35fr_.65fr]">
      <form onSubmit={submit} className="glass rounded-3xl p-6"><div className="grid gap-5 sm:grid-cols-2">{Object.keys(initial).map(field)}</div><button disabled={loading} className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-500 to-violet-600 px-5 py-3 font-semibold disabled:opacity-60">{loading?<><Loader2 className="animate-spin" size={18}/>Analyzing...</>:<><Sparkles size={18}/>Predict Churn</>}</button>{error&&<div className="mt-4 flex gap-2 rounded-xl border border-red-400/20 bg-red-400/10 p-4 text-sm text-red-200"><AlertCircle size={18}/>{error}</div>}</form>
      <div className="glass rounded-3xl p-6">{!result?<div className="grid h-full min-h-[420px] place-items-center text-center"><div><Sparkles className="mx-auto text-blue-400" size={38}/><h2 className="mt-4 text-xl font-semibold">Prediction result</h2><p className="mt-2 text-sm leading-6 text-slate-500">Submit the form to generate a real prediction from the trained model.</p></div></div>:
      <div><div className="flex items-center gap-2 text-emerald-300"><CheckCircle2 size={18}/>Model prediction complete</div><h2 className="mt-6 text-sm text-slate-400">Churn Probability</h2><div className="mt-2 text-5xl font-black">{result.probability_percent}%</div><div className={`mt-4 inline-flex rounded-full px-3 py-1 text-sm ${result.risk_level==='High'?'bg-red-400/10 text-red-300':result.risk_level==='Medium'?'bg-amber-400/10 text-amber-300':'bg-emerald-400/10 text-emerald-300'}`}>{result.risk_level} Risk</div><div className="mt-6 h-3 overflow-hidden rounded-full bg-slate-800"><div className="h-full rounded-full bg-gradient-to-r from-blue-400 to-rose-400" style={{width:`${result.probability_percent}%`}}/></div><div className="mt-6 rounded-2xl bg-slate-900/60 p-5"><div className="text-xs uppercase tracking-wider text-slate-500">Prediction</div><div className="mt-1 text-xl font-bold">{result.prediction}</div></div><div className="mt-6"><div className="font-semibold">Retention suggestions</div><ul className="mt-3 space-y-2 text-sm text-slate-400">{result.recommendations.map(x=><li key={x} className="flex gap-2"><span className="text-blue-400">•</span>{x}</li>)}</ul></div></div>}</div>
    </div>
  </div>
}
