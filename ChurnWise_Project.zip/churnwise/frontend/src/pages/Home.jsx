import { Link } from 'react-router-dom'
import { ArrowRight, BrainCircuit, Gauge, ShieldCheck, BarChart3, UserRound, Zap } from 'lucide-react'
import { useEffect, useState } from 'react'
import { api } from '../services/api'

export default function Home() {
  const [stats,setStats]=useState(null)
  useEffect(()=>{api.dashboard().then(setStats).catch(()=>{})},[])
  const churn = stats?.churn_percentage ?? 0
  return <div className="grid-bg">
    <section className="mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-[1.05fr_.95fr] lg:items-center lg:py-28">
      <div>
        <div className="mb-5 inline-flex rounded-full border border-blue-400/20 bg-blue-400/10 px-4 py-2 text-xs text-blue-200">✦ Smarter decisions. Happier customers.</div>
        <h1 className="max-w-3xl text-5xl font-black leading-[1.05] tracking-tight sm:text-6xl">AI-Powered Customer <span className="gradient-text">Churn Prediction</span></h1>
        <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-400">Predict customer churn before it happens. Analyze customer behavior using machine learning and identify customers at risk, so you can take action and improve retention.</p>
        <div className="mt-8 flex flex-wrap gap-4"><Link to="/predict" className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-500 to-violet-600 px-6 py-3 font-semibold shadow-glow">Start Prediction <ArrowRight size={18}/></Link><Link to="/dashboard" className="rounded-xl border border-blue-300/25 px-6 py-3 font-semibold text-slate-200 hover:bg-blue-500/10">View Dashboard</Link></div>
      </div>
      <div className="glass relative overflow-hidden rounded-3xl p-6 shadow-glow">
        <div className="absolute -right-20 -top-20 h-48 w-48 rounded-full bg-violet-600/20 blur-3xl"/>
        <div className="flex items-center justify-between"><div className="text-sm font-semibold tracking-wide text-slate-300">CHURN ANALYTICS</div><BarChart3 className="text-blue-400"/></div>
        <div className="mt-8 grid grid-cols-2 gap-6">
          <div className="flex items-center justify-center"><div className="grid h-44 w-44 place-items-center rounded-full" style={{background:`conic-gradient(#fb7185 ${churn}%, #1e293b 0)`}}><div className="grid h-32 w-32 place-items-center rounded-full bg-[#071025]"><div className="text-center"><div className="text-3xl font-bold">{churn}%</div><div className="text-xs text-slate-500">Churn rate</div></div></div></div></div>
          <div className="space-y-5"><div><div className="text-xs text-slate-500">Total Predictions</div><div className="text-2xl font-bold">{stats?.total_predictions ?? 0}</div></div><div><div className="text-xs text-slate-500">Churn Predictions</div><div className="text-2xl font-bold">{stats?.churn_predictions ?? 0}</div></div><div><div className="text-xs text-slate-500">Current status</div><div className="text-sm text-emerald-300">{stats ? 'Live API connected' : 'Connect backend to view analytics'}</div></div></div>
        </div>
      </div>
    </section>
    <section className="border-y border-blue-400/10 bg-[#071126] px-5 py-20"><div className="mx-auto max-w-6xl"><div className="text-center"><div className="text-xs font-semibold tracking-[.25em] text-blue-400">SIMPLE STEPS</div><h2 className="mt-2 text-3xl font-bold">How It Works</h2></div><div className="mt-12 grid gap-8 md:grid-cols-3">{[['01',UserRound,'Enter Customer Details','Provide customer information such as demographics, plan and usage.'],['02',BrainCircuit,'AI Analysis','The machine learning model analyzes the data and calculates churn probability.'],['03',BarChart3,'Get Result','View probability, risk level and actionable retention insights.']].map(([n,I,t,d])=><div key={n} className="text-center"><div className="mx-auto mb-5 grid h-14 w-14 place-items-center rounded-full bg-blue-500/10 text-blue-300"><I/></div><div className="text-xs text-blue-400">{n}</div><h3 className="mt-2 font-semibold">{t}</h3><p className="mt-2 text-sm leading-6 text-slate-400">{d}</p></div>)}</div></div></section>
    <section className="mx-auto grid max-w-7xl gap-4 px-5 py-12 sm:grid-cols-2 lg:grid-cols-4">{[[ShieldCheck,'Real Model','No hardcoded prediction results'],[Zap,'Fast API','Flask REST prediction endpoint'],[BrainCircuit,'ML Powered','Scikit-learn classification pipeline'],[Gauge,'Analytics','Live SQLite prediction history']].map(([I,t,d])=><div key={t} className="glass rounded-2xl p-5"><I className="text-blue-400"/><div className="mt-4 font-semibold">{t}</div><div className="mt-1 text-xs leading-5 text-slate-500">{d}</div></div>)}</section>
  </div>
}
