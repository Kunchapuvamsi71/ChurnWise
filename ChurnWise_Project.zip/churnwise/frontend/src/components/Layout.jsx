import Navbar from './Navbar'
export default function Layout({children}) {
  return <div className="min-h-screen bg-[#050b1d]"><Navbar/><main>{children}</main><footer className="border-t border-blue-400/10 py-8 text-center text-xs text-slate-500">ChurnWise · ML-powered customer retention analytics</footer></div>
}
