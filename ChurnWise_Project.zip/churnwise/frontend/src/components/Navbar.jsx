import { NavLink } from 'react-router-dom'
import { BarChart3, Menu, X } from 'lucide-react'
import { useState } from 'react'

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const links = [['Home','/'],['Predict','/predict'],['Dashboard','/dashboard'],['History','/history'],['About','/about']]
  return (
    <header className="sticky top-0 z-50 border-b border-blue-400/10 bg-[#050b1d]/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <NavLink to="/" className="flex items-center gap-3">
          <div className="rounded-xl bg-gradient-to-br from-blue-500 to-violet-600 p-2 shadow-glow"><BarChart3 size={22}/></div>
          <div><div className="text-lg font-bold">Churn<span className="text-blue-400">Wise</span></div><div className="text-[10px] tracking-widest text-slate-500">PREDICT · RETAIN · GROW</div></div>
        </NavLink>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button>
        <nav className={`${open ? 'absolute left-0 top-full flex w-full' : 'hidden'} flex-col gap-2 border-b border-blue-400/10 bg-[#050b1d] p-4 md:static md:flex md:w-auto md:flex-row md:items-center md:border-0 md:bg-transparent md:p-0`}>
          {links.map(([label,path]) => <NavLink key={path} onClick={()=>setOpen(false)} to={path} className={({isActive}) => `rounded-lg px-4 py-2 text-sm ${isActive ? 'bg-blue-500/10 text-blue-300' : 'text-slate-300 hover:text-white'}`}>{label}</NavLink>)}
          <button className="ml-1 rounded-xl border border-blue-300/30 px-5 py-2 text-sm font-medium hover:bg-blue-500/10">Login</button>
        </nav>
      </div>
    </header>
  )
}
