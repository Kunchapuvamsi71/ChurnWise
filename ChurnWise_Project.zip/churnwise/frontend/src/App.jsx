import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Predict from './pages/Predict'
import Dashboard from './pages/Dashboard'
import History from './pages/History'
import About from './pages/About'

export default function App(){return <BrowserRouter><Layout><Routes><Route path="/" element={<Home/>}/><Route path="/predict" element={<Predict/>}/><Route path="/dashboard" element={<Dashboard/>}/><Route path="/history" element={<History/>}/><Route path="/about" element={<About/>}/></Routes></Layout></BrowserRouter>}
